package com.example.propertyFinder.enums;

public enum Role {
	CUSTOMER,
	OWNER
}
