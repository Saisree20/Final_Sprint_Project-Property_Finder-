package com.example.propertyFinder.enums;

public enum PropertyType {
	RESIDENTIAL,
	COMMERCIAL
}
