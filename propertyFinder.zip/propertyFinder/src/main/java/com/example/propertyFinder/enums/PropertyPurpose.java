package com.example.propertyFinder.enums;

public enum PropertyPurpose {
	RENT,
	SELL
}
