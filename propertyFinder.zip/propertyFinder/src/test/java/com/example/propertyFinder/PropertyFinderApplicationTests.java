package com.example.propertyFinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyFinderApplicationTests {

	@Test
	void contextLoads() {
	}

}
